// 月次レポート
export function buildInvoiceTitle() {
  return "Monthly invoice";
}

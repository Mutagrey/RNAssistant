// 月次レポート
export function buildInvoiceTitle() {
  return "Old invoice";
}

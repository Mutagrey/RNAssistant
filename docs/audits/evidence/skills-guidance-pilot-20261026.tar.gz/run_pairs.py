import os,subprocess,time,json,hashlib
from pathlib import Path
root=Path(__file__).parent
repo=Path(os.environ['RNA_REPO']).resolve()
dlls={'A':root/'baseline/tests/RNAssistant.Harness/bin/Debug/net8.0/RNAssistant.Harness.dll','B':repo/'tests/RNAssistant.Harness/bin/Debug/net8.0/RNAssistant.Harness.dll'}
manifest=json.loads((root/'manifest.json').read_text());manifest['sharedHarnessFix']='Bypass scripted FixtureCompletion envelope for live model responses';manifest['invalidRuns']=['local-A','local-B'];manifest['runs']=[]
for v,dll in dlls.items():manifest['variants'][v]['fixedHarnessSha256']=hashlib.sha256(dll.read_bytes()).hexdigest()
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for profile,v in [('local','B'),('local','A'),('cloud','A'),('cloud','B')]:
 name=profile+'-'+v+'-fixed'
 env={k:value for k,value in os.environ.items() if not k.startswith('RNA_')}
 env.update(RNA_BASE_URL='http://127.0.0.1:11434/v1',RNA_MODEL='rna-gemma4-12b-32k:latest' if profile=='local' else 'gemma4:cloud',RNA_RESPONSE_MODE='json_schema' if profile=='local' else 'json_object',RNA_CONTEXT_TOKENS='32768',RNA_INSTRUCTION_ROLE='developer',RNA_REASONING_MODE='reasoning_effort')
 if profile=='cloud' and v=='A':
  subprocess.run(['ollama','stop','rna-gemma4-12b-32k:latest'],capture_output=True,timeout=20)
 start=time.monotonic()
 with (root/(name+'.log')).open('w') as log:
  proc=subprocess.run(['dotnet',str(dlls[v]),'--vba-workflow-live',str(root/name)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=540)
 result={'name':name,'exitCode':proc.returncode,'seconds':round(time.monotonic()-start,2)}
 acceptance=root/name/'acceptance.json'
 if acceptance.exists():result.update(json.loads(acceptance.read_text()))
 manifest['runs'].append(result);(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(result),flush=True)
